Paulo Roberto Andrade Filho RA156951 LAB3 EA872
Modificações realizadas nos arquivos
-- LAB2
As interfaces das classes foram modificadas conforme o LAB1: corpo agora possui campo aceleração, constante de amortecimento e constante da mola,
além dos getters desses campos. Física foi alterado para refletir o comportamento de uma mola. 
Tela foi alterado para quando a posição for menor que 0 ou maior que a altura máxima, nao mostrar nada. 
Além disso, foi somado um valor médio da altura para que o eixo y começasse no meio do eixo x. 
Foi colocado, quando o terminal tiver suporte, cor nas bolinhas oscilantes.
--
-- LAB3
A função update foi atualizada para que, quando o botão W ou S for apertado, seja aplicada uma força positiva ou negativa, respectivamente.
-- 
